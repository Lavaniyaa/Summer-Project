import os
import cmd_map as cmd

answer = cmd.cmdmap("ls")
print(answer)
