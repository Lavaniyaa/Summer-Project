import os
import json

log_dir = "finalised/"
cwd_path = os.getcwd()
dir_path = os.path.join(cwd_path, log_dir)
print(dir_path)

def cmdmap(commandname):
	for filename in os.listdir(dir_path):
			if filename[:-4] == commandname:
				file = open(dir_path+filename, 'r') 
				cd = file.read()
				return cd.split()
